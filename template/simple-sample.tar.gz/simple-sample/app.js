const app = require('express')()

app.get('/', (req, res) => {
  res.send("Hello from Appsody!");
});

app.get('/test', (req, res) => {
  res.send("Testing a new Template in Appsody!!");
});

module.exports.app = app;
